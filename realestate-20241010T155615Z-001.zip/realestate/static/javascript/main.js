const contribute = () => {
  var x = document.getElementById("db-form");
  x.style.display = "flex";
};
